$(document).ready(function () {

    $("#top").mouseover(function () {
        $(this).css("background-color", "red");
        $("#cube").addClass("top");
    });
    $("#top").mouseout(function () {
        $(this).css("background-color", "inherit");
        $("#cube").removeClass("top");
    });

    $("#left").mouseover(function () {
        $(this).css("background-color", "green");
        $("#cube").addClass("left");
    });
    $("#left").mouseout(function () {
        $(this).css("background-color", "inherit");
        $("#cube").removeClass("left");
    });

    $("#front").mouseover(function () {
        $(this).css("background-color", "yellow");
        $("#cube").addClass("front");
    });
    $("#front").mouseout(function () {
        $(this).css("background-color", "inherit");
        $("#cube").removeClass("front");
    });


});
